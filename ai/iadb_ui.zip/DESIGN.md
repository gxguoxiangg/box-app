---
name: Carbon Mobile Utility
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#424656'
  inverse-surface: '#303030'
  inverse-on-surface: '#f2f0f0'
  outline: '#737687'
  outline-variant: '#c3c6d8'
  surface-tint: '#0052dd'
  primary: '#004ccd'
  on-primary: '#ffffff'
  primary-container: '#0f62fe'
  on-primary-container: '#f3f3ff'
  inverse-primary: '#b4c5ff'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#9e3100'
  on-tertiary: '#ffffff'
  tertiary-container: '#c84000'
  on-tertiary-container: '#fff1ed'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174c'
  on-primary-fixed-variant: '#003da9'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#ffdbd0'
  tertiary-fixed-dim: '#ffb59d'
  on-tertiary-fixed: '#390c00'
  on-tertiary-fixed-variant: '#832700'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
  canvas: '#ffffff'
  surface-1: '#f4f4f4'
  surface-2: '#e0e0e0'
  ink: '#161616'
  ink-muted: '#525252'
  ink-subtle: '#8c8c8c'
  blue-hover: '#0050e6'
  blue-active: '#002d9c'
  semantic-success: '#24a148'
  semantic-warning: '#f1c21b'
  semantic-error: '#da1e28'
  hairline: '#e0e0e0'
  hairline-strong: '#161616'
typography:
  display:
    fontFamily: IBM Plex Sans
    fontSize: 36px
    fontWeight: '300'
    lineHeight: 44px
    letterSpacing: -0.4px
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0px
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.16px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.16px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.32px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.16px
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.32px
  button:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.16px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system translates the industrial precision and intellectual rigor of enterprise computing into an ergonomics-first Android and Flutter utility environment. It combines modern functional minimalism with architectural structure, prioritizing rapid scanning, precise data manipulation, and high throughput. 

The aesthetic is crisp, modular, and uncompromisingly engineered. By pairing Carbon's distinctive 0px sharp baseline grids with tactile mobile adaptations—such as pill-shaped quick actions and elongated touch chips—the system preserves brand authority while catering specifically to thumb-reach ergonomics and Material 3 interaction standards. The emotional tone is dependable, utilitarian, and calm under high information density.

## Colors

The color palette centers entirely around a single chromatic anchor: the signature high-clarity blue (`#0f62fe`). The rest of the interface is governed by disciplined grayscale contrasts that maximize readability in varying ambient light conditions on mobile screens.

- **Primary (`#0f62fe`)**: Reserved exclusively for high-intent actions, active toggles, primary buttons, system progress indicators, and selection affordances.
- **Secondary (`#161616`)**: Serves as the primary ink for critical headings and dark container fills, anchoring high-contrast touch points.
- **Surfaces (`#ffffff`, `#f4f4f4`, `#e0e0e0`)**: Surfaces do not use tinted chromatic gray; they rely on pure neutral tone steps to distinguish structural tiers, cards, and input backgrounds.
- **Semantics**: Functional alerts utilize strictly calibrated status tokens (`#24a148` for verified/complete states, `#f1c21b` for warnings, `#da1e28` for destructive actions and inline form faults).

## Typography

The typography scale is executed purely in IBM Plex Sans, carrying over Carbon’s light display presence (`fontWeight: 300`) into mobile headlines to eliminate corporate visual weight while maintaining distinct technical character. 

- Large titles scale tightly between 28px and 36px to prevent awkward word wrapping on handheld viewports.
- Body and label copy enforce explicit tabular clarity, maintaining consistent line heights calibrated to a 4px baseline grid.
- Numeric metrics and operational values must use Plex Sans's default proportional figures with open tracking to support rapid ocular scanning in diagnostic views.

## Layout & Spacing

The mobile layout operates on a strict 4-column fluid grid tailored to mobile portrait viewports, using a 16px outer margin and 16px gutters. For responsive foldables or horizontal tablet orientations, it expands to 8 columns with 24px margins.

Spacing follows an unyielding 4px/8px incremental rhythm:
- Vertical rhythm strictly adheres to multiples of 8px (`space-sm` for compact group items, `space-md` for standard component interior spacing, and `space-xl` for sectional division).
- Touch safety is enforced globally: interactive components must maintain a min-height or tap footprint of 48px, regardless of interior label bounding boxes.
- Data densities can be toggled to compact mode in Flutter/Android tables by dropping internal row padding to 8px while keeping touch interception at the full 48px boundary via hit-test padding.

## Elevation & Depth

True to Carbon’s architectural roots, visual separation is achieved without ambient blur or drop shadows. Depth is conveyed strictly through tonal surface layering and razor-sharp border strokes.

- **Base Layer (Canvas)**: Uses `#ffffff` as the default application ground.
- **Card and Section Containers**: Rely on `#f4f4f4` (`surface-1`) to construct visible contrast or an explicit `1px solid #e0e0e0` stroke on pure white surfaces.
- **Android Bottom Navigation Bar**: Anchored flush to the bottom edge with a top boundary of `1px solid #e0e0e0`, eliminating diffuse elevation drops.
- **Floating Overlays & Modals**: Render with zero blur radius, relying on a solid 1px hairline border (`#e0e0e0`) and high-contrast scrim (`rgba(22, 22, 22, 0.48)`).

## Shapes

The foundational shape paradigm is set to zero border-radius (`0px`), preserving the engineered aesthetic across foundational structural surfaces, bottom sheets, form input containers, and structural card grids.

### Mobile Hybrid Rule
To balance engineered precision with tactile handheld usability, targeted exceptions apply to micro-interactive controls:
- **Quick-Action Buttons & FABs**: Use full pill radii (`rounded.full` / `9999px`) to create clear visual separation between fixed structural tiles and urgent ergonomic actions.
- **Filter Chips**: Use elongated pill contours (`9999px`) to match Android gesture paradigms and signal horizontal scrollability.
- **Inputs, Cards, and System Shells**: Retain sharp `0px` corners, maintaining the distinctive enterprise discipline.

## Components

### Buttons
- **Primary**: Solid `#0f62fe` background, `#ffffff` text, 48px height, 16px horizontal padding. Zero border-radius for full-width structural actions; pill-shaped (`9999px`) when used as floating quick actions or speed dials.
- **Secondary**: Solid `#161616` background with `#ffffff` text.
- **Tertiary**: Transparent background with a `1px solid #0f62fe` outline and `#0f62fe` typography.
- **Feedback**: Active states transition to `#002d9c` with zero elevation lift.

### Chips & Filter Pills
- **Container**: 32px height, 12px horizontal padding, full pill radius (`9999px`).
- **Unselected**: `#f4f4f4` fill, `#161616` text, no border.
- **Selected**: `#0f62fe` fill, `#ffffff` text, accompanied by an integrated dismissal icon.

### Android Navigation Bar
- Fixed 56px height, pure `#ffffff` background with a top `1px solid #e0e0e0` boundary.
- Active tabs display a 2px top indicator in `#0f62fe` with an active icon and `label-sm` typography; unselected items use `#525252`.

### Input Fields
- Solid `#f4f4f4` container fill, 48px minimum height, zero border-radius.
- Bottom boundary carries a 1px `#161616` line. On focus, this stroke shifts to a 2px `#0f62fe` indicator. Error states replace the bottom underline with a 2px `#da1e28` stroke and display caption error text below.

### Cards & Tiles
- Flat `#ffffff` surface bounded by a `1px solid #e0e0e0` stroke, or an unbordered container filled with `#f4f4f4`.
- Sharp 0px corners, 16px interior padding, and strict vertical stacking for data rows.